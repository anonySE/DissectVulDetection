from preprocess_dl_Input_version5 import *
import numpy as np
import tensorflow as tf
import pickle
import time
import math
import os
import os.path as osp
import pandas as pd
import argparse
from models import *
import csv

RANDOMSEED = 2021  # for reproducibility
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"


def main(traindataSet_path, weightPath, batch_size, maxlen,
         vector_dim, build_model, epoch, resume, eval_freq):
    model = build_model(maxlen, vector_dim)
    start_epoch = 0
    checkpoint_path = osp.join(weightPath, "cp.ckpt")
    log_path = osp.join(weightPath, "log.csv")
    if resume:
        try:
            model.load_weights(checkpoint_path)  # load weights of trained models
        except:
            print()
        if osp.exists(log_path):
            with open(log_path, newline='') as csvfile:
                reader = csv.DictReader(csvfile)
                while reader.fieldnames:
                    prereader = reader
                    reader = csv.DictReader(csvfile)
                start_epoch = int(prereader.fieldnames[0]) + 1

    print("Loading Train data...")

    dataset = []
    labels = []
    for filename in os.listdir(traindataSet_path):
        if filename.endswith(".pkl") is False:
            continue
        print(filename)
        f = open(os.path.join(traindataSet_path, filename), "rb")
        # 分别是样本向量、句子拆分点、漏洞点、goodbad函数表、testcase切片名
        dataset_file, label = pickle.load(f)
        f.close()
        dataset += dataset_file
        labels += label
    print(len(dataset))
    # dataset = dataset[:300]
    # labels = labels[:300]
    train_vul = 0
    test_vul = 0
    np.random.seed(int(time.time()))
    test_index = np.random.choice(len(dataset), int(len(dataset) * 0.2), replace=False)
    for i, label in enumerate(labels):
        if label == 1:
            if i in test_index:
                test_vul += 1
            else:
                train_vul += 1

    train_dataset = []
    train_label = []
    test_dataset = []
    test_label = []

    for i in range(len(dataset)):
        if i in test_index:
            test_dataset.append(dataset[i])
            test_label.append(labels[i])
        else:
            train_dataset.append(dataset[i])
            train_label.append(labels[i])

    # 按照漏洞点和所属函数生成0/1标签

    train_nonvul = len(train_dataset) - train_vul
    test_nonvul = len(test_dataset) - test_vul
    print("train_vul: ", train_vul, "train_non_vul: ", train_nonvul)
    print("test_vul: ", test_vul, "test_non_vul: ", test_nonvul)

    bin_labels = []
    for label in train_label:
        bin_labels.append(multi_labels_to_two(label))
    train_label = np.array(bin_labels)
    bin_labels = []
    for label in test_label:
        bin_labels.append(multi_labels_to_two(label))
    test_label = np.array(bin_labels)

    np.random.seed(RANDOMSEED)
    np.random.shuffle(train_dataset)
    np.random.seed(RANDOMSEED)
    np.random.shuffle(train_label)
    np.random.seed(RANDOMSEED)
    np.random.shuffle(test_dataset)
    np.random.seed(RANDOMSEED)
    np.random.shuffle(test_label)

    train_generator = generator_of_data(train_dataset, train_label, batch_size, maxlen, vector_dim)
    all_train_samples = len(train_dataset)
    train_steps_epoch = int(all_train_samples / batch_size)

    test_generator = generator_of_data(test_dataset, test_label, 1, maxlen, vector_dim)
    all_test_samples = len(test_dataset)
    test_steps_epoch = all_test_samples

    # print("Loading Test data...")
    # dataset = []
    # labels = []
    #
    # for filename in os.listdir(testdataSet_path):
    #     if filename.endswith(".pkl") is False:
    #         continue
    #     print(filename)
    #     f = open(os.path.join(testdataSet_path, filename), "rb")
    #     # 分别是样本向量、句子拆分点、漏洞点、goodbad函数表、句子语料、testcase切片名
    #     dataset_file, label = pickle.load(f)
    #     f.close()
    #     dataset += dataset_file
    #     labels += label
    # print(len(dataset))
    #
    # # 按照漏洞点和所属函数生成0/1标签
    # # 按照漏洞点和所属函数生成0/1标签
    # test_vul = 0
    # test_nonvul = 0
    # for i, label in enumerate(labels):
    #     if label == 1:
    #         test_vul += 1
    #         labels[i] = 1
    #     else:
    #         labels[i] = 0
    #         test_nonvul += 1
    #
    # print("vul: ", test_vul, "non_vul: ", test_nonvul)
    #
    # bin_labels = []
    # for label in labels:
    #     bin_labels.append(multi_labels_to_two(label))
    # labels = np.array(bin_labels)
    #
    # test_generator = generator_of_data(dataset, labels, 1, maxlen, vector_dim)
    # all_test_samples = len(dataset)
    # test_steps_epoch = int(math.ceil(all_test_samples / 1))

    print("start")
    t1 = time.time()
    modelcheckpoint = tf.keras.callbacks.ModelCheckpoint(
        filepath=checkpoint_path,
        save_weights_only=True,
        save_freq=train_steps_epoch,
        verbose=1)
    csv_logger = tf.keras.callbacks.CSVLogger(log_path, append=True)
    print("start_fit")

    model.fit(x=train_generator, steps_per_epoch=train_steps_epoch,
              epochs=epoch, callbacks=[modelcheckpoint, csv_logger],
              initial_epoch=start_epoch, validation_data=test_generator,
              validation_freq=eval_freq, validation_steps=test_steps_epoch)
    print("end_fit")
    t2 = time.time()
    train_time = t2 - t1

    print("Train time: ", train_time)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--trainpath", type=str)
    parser.add_argument("--weightpath", type=str)
    parser.add_argument("--model", type=str)
    parser.add_argument("--epoch", type=int)
    parser.add_argument("--resume", dest="resume", action="store_true")
    parser.add_argument("--no-resume", dest="resume", action="store_false")
    parser.add_argument("--vectordim", type=int, default=30)
    parser.add_argument("--eval_freq", type=int, default=10)
    parser.set_defaults(resume=True)
    args = parser.parse_args()
    resume = args.resume
    batchSize = 32
    vectorDim = args.vectordim
    maxLen = 900
    layers = 2
    traindataSetPath = args.trainpath
    weightPath = './model_gen'
    if not os.path.exists(weightPath):
        os.mkdir(weightPath)
    weightPath = args.weightpath
    if not os.path.exists(weightPath):
        os.mkdir(weightPath)
    if args.model == "bgru":
        build_model = build_BGRU
    if args.model == "gru":
        build_model = build_GRU
    if args.model == "lstm":
        build_model = build_LSTM
    if args.model == "bilstm":
        build_model = build_BILSTM
    main(traindataSetPath, weightPath, batchSize, maxLen, vectorDim, build_model,
         args.epoch, resume, args.eval_freq)
    # testrealdata(realtestdataSetPath, weightPath, batchSize, maxLen, vectorDim, layers, dropout)
