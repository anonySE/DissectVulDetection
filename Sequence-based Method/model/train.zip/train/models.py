from tensorflow import keras


def build_BGRU(maxlen, vector_dim, layers=2, dropout=0.1, units=512, use_bias=True):
    print('Build BGRU models...')
    model = keras.models.Sequential()

    model.add(keras.layers.Masking(mask_value=0.0, input_shape=(maxlen, vector_dim)))

    for i in range(1, layers):
        model.add(keras.layers.Bidirectional(
            keras.layers.GRU(units=units, activation='tanh', recurrent_activation='hard_sigmoid', return_sequences=True,
                             use_bias=use_bias)))
        model.add(keras.layers.Dropout(dropout))

    model.add(
        keras.layers.Bidirectional(keras.layers.GRU(units=units, activation='tanh', recurrent_activation='hard_sigmoid',
                                                    use_bias=use_bias)))
    model.add(keras.layers.Dropout(dropout))

    model.add(keras.layers.Dense(1, activation='sigmoid'))

    """models.compile(loss='binary_crossentropy', optimizer='adamax',
                  metrics=[tf.keras.metrics.TruePositives(),
                           tf.keras.metrics.FalsePositives(),
                           tf.keras.metrics.FalseNegatives(),
                           tf.keras.metrics.Precision(),
                           tf.keras.metrics.Recall()])"""
    FP_count = keras.metrics.FalsePositives()
    FN_count = keras.metrics.FalseNegatives()
    TN_count = keras.metrics.TrueNegatives()
    TP_count = keras.metrics.TruePositives()
    precision = keras.metrics.Precision()
    recall = keras.metrics.Recall()
    model.compile(loss='binary_crossentropy', optimizer='adamax',
                  metrics=[FP_count, FN_count, TN_count, TP_count, precision, recall, 'accuracy'])

    model.summary()

    return model


def build_BILSTM(maxlen, vector_dim, layers=2, dropout=0.1, units=512, use_bias=True):
    print('Build BILSTM models...')
    model = keras.models.Sequential()

    model.add(keras.layers.Masking(mask_value=0.0, input_shape=(maxlen, vector_dim)))

    for i in range(1, layers):
        model.add(keras.layers.Bidirectional(
            keras.layers.LSTM(units=units, activation='tanh', recurrent_activation='hard_sigmoid',
                              return_sequences=True,
                              use_bias=use_bias)))
        model.add(keras.layers.Dropout(dropout))

    model.add(
        keras.layers.Bidirectional(
            keras.layers.LSTM(units=units, activation='tanh', recurrent_activation='hard_sigmoid',
                              use_bias=use_bias)))
    model.add(keras.layers.Dropout(dropout))

    model.add(keras.layers.Dense(1, activation='sigmoid'))

    """models.compile(loss='binary_crossentropy', optimizer='adamax',
                  metrics=[tf.keras.metrics.TruePositives(),
                           tf.keras.metrics.FalsePositives(),
                           tf.keras.metrics.FalseNegatives(),
                           tf.keras.metrics.Precision(),
                           tf.keras.metrics.Recall()])"""

    FP_count = keras.metrics.FalsePositives()
    FN_count = keras.metrics.FalseNegatives()
    TN_count = keras.metrics.TrueNegatives()
    TP_count = keras.metrics.TruePositives()
    precision = keras.metrics.Precision()
    recall = keras.metrics.Recall()
    model.compile(loss='binary_crossentropy', optimizer='adamax',
                  metrics=[FP_count, FN_count, TN_count, TP_count, precision, recall, 'accuracy'])

    model.summary()

    return model


def build_GRU(maxlen, vector_dim, layers=2, dropout=0.1, units=512, use_bias=True):
    print('Build GRU models...')
    model = keras.models.Sequential()

    model.add(keras.layers.Masking(mask_value=0.0, input_shape=(maxlen, vector_dim)))

    for i in range(1, layers):
        model.add(keras.layers.GRU(units=units, activation='tanh', recurrent_activation='hard_sigmoid',
                                   return_sequences=True,
                                   use_bias=use_bias))
        model.add(keras.layers.Dropout(dropout))

    model.add(keras.layers.GRU(units=units, activation='tanh', recurrent_activation='hard_sigmoid',
                               use_bias=use_bias))
    model.add(keras.layers.Dropout(dropout))

    model.add(keras.layers.Dense(1, activation='sigmoid'))

    """models.compile(loss='binary_crossentropy', optimizer='adamax',
                  metrics=[tf.keras.metrics.TruePositives(),
                           tf.keras.metrics.FalsePositives(),
                           tf.keras.metrics.FalseNegatives(),
                           tf.keras.metrics.Precision(),
                           tf.keras.metrics.Recall()])"""

    FP_count = keras.metrics.FalsePositives()
    FN_count = keras.metrics.FalseNegatives()
    TN_count = keras.metrics.TrueNegatives()
    TP_count = keras.metrics.TruePositives()
    precision = keras.metrics.Precision()
    recall = keras.metrics.Recall()
    model.compile(loss='binary_crossentropy', optimizer='adamax',
                  metrics=[FP_count, FN_count, TN_count, TP_count, precision, recall, 'accuracy'])

    model.summary()

    return model


def build_LSTM(maxlen, vector_dim, layers=2, dropout=0.1, units=512, use_bias=True):
    print('Build LSTM models...')
    model = keras.models.Sequential()

    model.add(keras.layers.Masking(mask_value=0.0, input_shape=(maxlen, vector_dim)))

    for i in range(1, layers):
        model.add(keras.layers.LSTM(units=units, activation='tanh', recurrent_activation='hard_sigmoid',
                                   return_sequences=True,
                                   use_bias=use_bias))
        model.add(keras.layers.Dropout(dropout))

    model.add(keras.layers.LSTM(units=units, activation='tanh', recurrent_activation='hard_sigmoid',
                               use_bias=use_bias))
    model.add(keras.layers.Dropout(dropout))

    model.add(keras.layers.Dense(1, activation='sigmoid'))

    """models.compile(loss='binary_crossentropy', optimizer='adamax',
                  metrics=[tf.keras.metrics.TruePositives(),
                           tf.keras.metrics.FalsePositives(),
                           tf.keras.metrics.FalseNegatives(),
                           tf.keras.metrics.Precision(),
                           tf.keras.metrics.Recall()])"""

    FP_count = keras.metrics.FalsePositives()
    FN_count = keras.metrics.FalseNegatives()
    TN_count = keras.metrics.TrueNegatives()
    TP_count = keras.metrics.TruePositives()
    precision = keras.metrics.Precision()
    recall = keras.metrics.Recall()
    model.compile(loss='binary_crossentropy', optimizer='adamax',
                  metrics=[FP_count, FN_count, TN_count, TP_count, precision, recall, 'accuracy'])

    model.summary()

    return model
